# basicCRUDops_NodeJs_sqlite

In this project, 'index.js' is the server application which will perform the basic CRUD operations on SQLite3 database from the web browser on the same local machine. Here, all the four operations are executed with GET requests only.
